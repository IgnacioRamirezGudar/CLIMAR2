//----------------------OCULTAR MENU---------------------
//-------------------------------------------------------
function animacion(){
    
    var accion = document.getElementsByClassName('sub-paginas');
    
    var accion2 = document.getElementsByClassName('caja');
    
    var accion3 = document.getElementsByClassName('degradado');
    
    for(var i=0; i < accion.length; i++){
        
        accion[i].classList.toggle('desaparece');
    
    }
    
    for(var i=0; i < accion2.length; i++){
        
        accion2[i].classList.toggle('desaparece2');
    
    }
    
    for(var i=0; i < accion3.length; i++){
        
        accion3[i].classList.toggle('desaparece3');
    
    }
    
}


//----------------------CARGAR PAGINA---------------------
//-------------------------------------------------------

window.onload = function(){
    
    var contenedor = document.getElementById('contenedor_carga');
    
    contenedor.style.visibility = 'hidden';
    contenedor.style.opacity  = '0';
    
}











//--------------------SUBIR FOTO-------------------------
//-------------------------------------------------------
/*var firebaseConfig = {
    apiKey: "AIzaSyAC_DmrNojnX1iG5FuGAediqYDgDBi_3BY",
    authDomain: "climar-826b1.firebaseapp.com",
    databaseURL: "https://climar-826b1-default-rtdb.firebaseio.com",
    projectId: "climar-826b1",
    storageBucket: "climar-826b1.appspot.com",
    messagingSenderId: "97268534949",
    appId: "1:97268534949:web:0d1fe2878aeda06cb6874c",
    measurementId: "G-XKLLEWG7KL"
  };

firebase.initializeApp(firebaseConfig);



var IMAGENES = firebase.database().ref('/ImagendelUsuario/');




const imgDiv = document.querySelector('.perfil-div','.perfil-div-2');

const img = document.querySelector('#photo');

const img2 = document.querySelector('#photo2');

const file = document.querySelector('#file');

const uploadBtn = document.querySelector('#uploadBtn');



imgDiv.addEventListener('mouseenter', function(){
    
    uploadBtn.style.display = "block";
    
});


imgDiv.addEventListener('mouseleave', function(){
    
    uploadBtn.style.display = "none";
    
});


file.addEventListener('change', function(){
  
 
    
    const choosedFile = this.files[0];
    
    if (choosedFile) {

        const reader = new FileReader();
        
        reader.addEventListener('load', function(){
            
            img.setAttribute('src', reader.result);
            
            img2.setAttribute('src', reader.result);
            
        });

        reader.readAsDataURL(choosedFile);
    }
});*/
