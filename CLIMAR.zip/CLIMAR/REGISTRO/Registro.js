//--------------------BASE DE REGISTRO---------------------
//---------------------------------------------------------

var firebaseConfig = {
    apiKey: "AIzaSyAC_DmrNojnX1iG5FuGAediqYDgDBi_3BY",
    authDomain: "climar-826b1.firebaseapp.com",
    databaseURL: "https://climar-826b1-default-rtdb.firebaseio.com",
    projectId: "climar-826b1",
    storageBucket: "climar-826b1.appspot.com",
    messagingSenderId: "97268534949",
    appId: "1:97268534949:web:0d1fe2878aeda06cb6874c",
    measurementId: "G-XKLLEWG7KL"
    };  
    
    firebase.initializeApp(firebaseConfig);
    const auth = firebase.auth();
    const fs = firebase.firestore();


// Registro
const signUpForm = document.querySelector(".contact-form");

signUpForm.addEventListener('submit', (e) => {
    
  e.preventDefault();
    
  const email = signUpForm["email"].value;
    
  const password = signUpForm["contra"].value;
    
  auth
    .createUserWithEmailAndPassword(email, password)
    
    .then((userCredential) => {
      
      signUpForm.reset();
      
    });
    
    document.getElementById('hola').innerHTML = "ERES: " + email;
    
    
});

// Login
const signInForm = document.querySelector(".login-form");

signInForm.addEventListener('submit', (e) => {
    
  e.preventDefault();
    
  const email = signInForm["login-email"].value;
    
  const password = signInForm["login-contra"].value;
    
    
  auth.signInWithEmailAndPassword(email, password).then((userCredential) => {
      
    signInForm.reset();
      
  });
});

// Logout
const logout = document.querySelector('#logout');

logout.addEventListener('click', (e) => {
  e.preventDefault();
  auth.signOut().then(() => {
    console.log("signup out");
  });
});



/*var firebaseConfig = {
    apiKey: "AIzaSyAC_DmrNojnX1iG5FuGAediqYDgDBi_3BY",
    authDomain: "climar-826b1.firebaseapp.com",
    databaseURL: "https://climar-826b1-default-rtdb.firebaseio.com",
    projectId: "climar-826b1",
    storageBucket: "climar-826b1.appspot.com",
    messagingSenderId: "97268534949",
    appId: "1:97268534949:web:0d1fe2878aeda06cb6874c",
    measurementId: "G-XKLLEWG7KL"
  };

firebase.initializeApp(firebaseConfig);

let contactInfo = firebase.database().ref("USUARIOS");


firebase.auth().onAuthStateChanged(function(user){
    
    if(user){
    
    var displayName = user.display;
    
    var email = user.email;
    
    var emailVerified = user.emailVerified;
    
    var photoURL = user.photoURL;
    
    var isAnonymous = user.isAnonymous;
    
    var uid = user.uid;
    
    var providerData = user.providerData;
    
    
    } else{
    
    
    }
    
});


function enviar(){
    
    var email = document.getElementById('email').value;
    
    var pass  = document.getElementById('contra').value;
    
    firebase.auth().createUserWithEmailAndPassword(email, pass).catch(function(error){
       
        var errorCode = error.code;
        
        var errorMessage = error.message;
        
        alert(errorMessage);
        
    });
    
    document.querySelector(".contact-form").addEventListener("submit", submitForm);

    
    
    function submitForm(e) {
    
        //var name  = document.getElementById('nombre').value;
        var email = document.getElementById('email').value;
        var pass  = document.getElementById('contra').value;
    
        e.preventDefault();

        console.log(email, pass);

        saveContactInfo(email, pass);

        document.querySelector(".contact-form").reset();
            

    }

    function saveContactInfo(name, email, pass) {
        
        let newContactInfo = contactInfo.push();
        
        
        
        newContactInfo.set({
        
        //name: name,
        
        email: email,
          
        pass: pass,
        
  });
    
}
}*/


function registra(){
    location.href = "../PERFIL/Perfil.html";
    document.getElementById('login').innerHTML = "ERES: " + user.email;
}